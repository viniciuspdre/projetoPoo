package com.lowagie.text.html.simpleparser;

