# Notice

This is only a fallback font for existing OpenPDF code. For using the full set of Liberation Fonts,
please add the openpdf-fonts-extra dependency to you project and use the class
`org.librepdf.openpdf.fonts.Liberation`.
