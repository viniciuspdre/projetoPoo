# Formatter Configuration

You can find in this directory the configuration files for the formatters used in this project. For IntelliJ IDEA
and Eclipse. If you have other IDE, please contribute with a configuration file. OpenPDF has it's own coding style.
It is based in the Google Java Style Guide, but with some modifications:

* Indentation: 4 spaces
* Line length: 120 characters
* Continuation indent: 8 spaces
