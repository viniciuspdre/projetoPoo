# Licenses

## Licenses of OpenPDF

### Mozilla Public License Version 2.0

Please see https://www.mozilla.org/en-US/MPL/2.0/ or the attached file
[MPL-2.0.txt](MPL-2.0.txt).

### GNU Lesser General Public License 2.1

Please see https://www.gnu.org/licenses/old-licenses/lgpl-2.1 or the attached file
[LGPL-2.1.md](LGPL-2.1.md).

#### Apache License, Version 2.0

Some files use code from different Apache projects. The source code of these files contains the appropriate copyright
notices as described in the Appendix of `http://www.apache.org/licenses/LICENSE-2.0`.

Please see https://www.apache.org/licenses/LICENSE-2.0 or the attached file
[APACHE-LICENSE-2.0.txt](APACHE-LICENSE-2.0.txt).

